package com.ultracraft.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "ultracraft_settings";
    private static final String AMETHYST_URL = "https://github.com/AngelAuraMC/Amethyst-Android";
    private static final String BEDROCK_URL = "https://play.google.com/store/apps/details?id=com.mojang.minecraftpe";

    private static final int BG = Color.rgb(10, 17, 13);
    private static final int PANEL = Color.rgb(20, 31, 24);
    private static final int PANEL_ALT = Color.rgb(27, 41, 31);
    private static final int GREEN = Color.rgb(71, 209, 108);
    private static final int TEXT = Color.rgb(238, 245, 239);
    private static final int MUTED = Color.rgb(157, 177, 162);

    private SharedPreferences prefs;
    private TextView javaStatus;
    private TextView bedrockStatus;
    private TextView selectedProfile;
    private TextView selectedVersion;
    private TextView performanceSummary;

    private final String[] versions = {"Latest supported", "1.21.x", "1.20.1", "1.19.4", "1.16.5"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateInstalledStatuses();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        // Android 15 enforces edge-to-edge for target SDK 35; keep content clear of system bars.
        scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(page);

        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        brandRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView mark = text("U", 24, Color.rgb(8, 22, 12), true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(round(GREEN, 12));
        LinearLayout.LayoutParams markLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        brandRow.addView(mark, markLp);
        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setPadding(dp(12), 0, 0, 0);
        brandText.addView(text("ULTRACRAFT", 19, TEXT, true));
        brandText.addView(text("ANDROID LAUNCHER  •  v1.0", 10, MUTED, true));
        brandRow.addView(brandText, new LinearLayout.LayoutParams(0, -2, 1));
        TextView versionPill = text("MOBILE", 10, GREEN, true);
        versionPill.setPadding(dp(10), dp(7), dp(10), dp(7));
        versionPill.setBackground(round(Color.rgb(25, 58, 35), 30));
        brandRow.addView(versionPill);
        page.addView(brandRow, bottom(0, 24));

        LinearLayout hero = panel(PANEL_ALT, 22);
        hero.setPadding(dp(20), dp(22), dp(20), dp(20));
        TextView eyebrow = text("YOUR WORLDS. ONE HOME.", 11, GREEN, true);
        hero.addView(eyebrow, bottom(0, 10));
        TextView heading = text("Ready to\ncraft something?", 29, TEXT, true);
        heading.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        hero.addView(heading, bottom(0, 10));
        hero.addView(text("A lightweight dashboard for your Minecraft launchers, profiles, and performance notes.", 14, MUTED, false), bottom(0, 18));
        TextView note = text("GAME FILES ARE NOT INCLUDED", 10, Color.rgb(191, 220, 197), true);
        note.setPadding(dp(10), dp(8), dp(10), dp(8));
        note.setBackground(round(Color.rgb(23, 48, 31), 8));
        hero.addView(note);
        page.addView(hero, bottom(0, 23));

        page.addView(sectionTitle("QUICK LAUNCH"), bottom(0, 10));
        LinearLayout launchRow = new LinearLayout(this);
        launchRow.setOrientation(LinearLayout.HORIZONTAL);
        Button javaBtn = button("▶  PLAY JAVA", true);
        javaBtn.setOnClickListener(v -> launchJava());
        Button bedrockBtn = button("PLAY BEDROCK", false);
        bedrockBtn.setOnClickListener(v -> launchBedrock());
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(54), 1);
        half.rightMargin = dp(6);
        launchRow.addView(javaBtn, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(54), 1);
        half2.leftMargin = dp(6);
        launchRow.addView(bedrockBtn, half2);
        page.addView(launchRow, bottom(0, 22));

        page.addView(sectionTitle("INSTALLED LAUNCHERS"), bottom(0, 10));
        LinearLayout javaCard = panel(PANEL, 16);
        javaCard.setPadding(dp(15), dp(14), dp(15), dp(14));
        LinearLayout javaRow = new LinearLayout(this);
        javaRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView javaIcon = smallIcon("J", Color.rgb(64, 119, 76));
        javaRow.addView(javaIcon, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout javaNames = new LinearLayout(this);
        javaNames.setOrientation(LinearLayout.VERTICAL);
        javaNames.setPadding(dp(12), 0, 0, 0);
        javaNames.addView(text("Minecraft: Java Edition", 14, TEXT, true));
        javaNames.addView(text("Amethyst / Pojav-compatible", 11, MUTED, false));
        javaRow.addView(javaNames, new LinearLayout.LayoutParams(0, -2, 1));
        javaStatus = text("Checking…", 11, MUTED, true);
        javaRow.addView(javaStatus);
        javaCard.addView(javaRow);
        page.addView(javaCard, bottom(0, 8));

        LinearLayout bedrockCard = panel(PANEL, 16);
        bedrockCard.setPadding(dp(15), dp(14), dp(15), dp(14));
        LinearLayout bedrockRow = new LinearLayout(this);
        bedrockRow.setGravity(Gravity.CENTER_VERTICAL);
        bedrockRow.addView(smallIcon("B", Color.rgb(60, 111, 150)), new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout bedrockNames = new LinearLayout(this);
        bedrockNames.setOrientation(LinearLayout.VERTICAL);
        bedrockNames.setPadding(dp(12), 0, 0, 0);
        bedrockNames.addView(text("Minecraft for Android", 14, TEXT, true));
        bedrockNames.addView(text("Bedrock Edition", 11, MUTED, false));
        bedrockRow.addView(bedrockNames, new LinearLayout.LayoutParams(0, -2, 1));
        bedrockStatus = text("Checking…", 11, MUTED, true);
        bedrockRow.addView(bedrockStatus);
        bedrockCard.addView(bedrockRow);
        page.addView(bedrockCard, bottom(0, 24));

        page.addView(sectionTitle("LOCAL PROFILE"), bottom(0, 10));
        LinearLayout profileCard = panel(PANEL, 18);
        profileCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        selectedProfile = text("Profile: " + prefs.getString("profile_name", "Survival Profile"), 16, TEXT, true);
        profileCard.addView(selectedProfile, bottom(0, 6));
        selectedVersion = text("Preferred version: " + prefs.getString("profile_version", "Latest supported"), 12, MUTED, false);
        profileCard.addView(selectedVersion, bottom(0, 12));
        Button editProfile = button("EDIT PROFILE", false);
        editProfile.setOnClickListener(v -> showProfileDialog());
        profileCard.addView(editProfile, new LinearLayout.LayoutParams(-1, dp(46)));
        TextView profileNote = text("This profile is saved in UltraCraft. Choose the actual game version and account inside your Java launcher.", 11, MUTED, false);
        profileNote.setPadding(0, dp(10), 0, 0);
        profileCard.addView(profileNote);
        page.addView(profileCard, bottom(0, 24));

        page.addView(sectionTitle("PERFORMANCE NOTES"), bottom(0, 10));
        LinearLayout perfCard = panel(PANEL, 18);
        perfCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        perfCard.addView(text("Choose a preset to keep your preferred setup saved.", 13, MUTED, false), bottom(0, 12));
        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Low-end", "Balanced", "Visuals"};
        for (String name : names) {
            Button preset = button(name, name.equals(prefs.getString("preset", "Balanced")));
            preset.setTextSize(11);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(43), 1);
            p.setMargins(dp(3), 0, dp(3), 0);
            presets.addView(preset, p);
            preset.setOnClickListener(v -> {
                prefs.edit().putString("preset", name).apply();
                showToast("Saved preset: " + name);
                buildScreen();
            });
        }
        perfCard.addView(presets, bottom(0, 11));
        String detail = performanceText(prefs.getString("preset", "Balanced"));
        performanceSummary = text(detail, 12, TEXT, false);
        perfCard.addView(performanceSummary);
        TextView perfNote = text("These are suggestions only; UltraCraft does not change RAM or graphics settings inside another app.", 10, MUTED, false);
        perfNote.setPadding(0, dp(10), 0, 0);
        perfCard.addView(perfNote);
        page.addView(perfCard, bottom(0, 23));

        page.addView(sectionTitle("NEED THE GAME LAUNCHER?"), bottom(0, 10));
        LinearLayout getCard = panel(PANEL, 16);
        getCard.setPadding(dp(16), dp(15), dp(16), dp(15));
        getCard.addView(text("Java Edition", 15, TEXT, true), bottom(0, 5));
        getCard.addView(text("Open the Amethyst project page to find its current official Android build and instructions.", 12, MUTED, false), bottom(0, 12));
        Button getJava = button("OPEN AMETHYST PROJECT", true);
        getJava.setOnClickListener(v -> openUrl(AMETHYST_URL));
        getCard.addView(getJava, new LinearLayout.LayoutParams(-1, dp(46)));
        page.addView(getCard, bottom(0, 18));

        TextView footer = text("ULTRACRAFT IS AN INDEPENDENT COMPANION APP. NOT AFFILIATED WITH MOJANG OR MICROSOFT. Minecraft game files and a valid account are not supplied.", 10, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setLineSpacing(dp(2), 1f);
        footer.setPadding(dp(8), dp(4), dp(8), dp(12));
        page.addView(footer);

        setContentView(scroll);
        updateInstalledStatuses();
    }

    private String performanceText(String preset) {
        if ("Low-end".equals(preset)) return "Suggested: lower render distance, fast graphics, particles minimal, and close background apps.";
        if ("Visuals".equals(preset)) return "Suggested: increase visual quality gradually and watch performance and device temperature.";
        return "Suggested: medium render distance, balanced graphics, and adjust one setting at a time.";
    }

    private void showProfileDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(8), dp(20), 0);
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("Profile name");
        name.setText(prefs.getString("profile_name", "Survival Profile"));
        form.addView(name, bottom(0, 10));
        TextView label = text("Preferred version (saved in this app only)", 12, MUTED, false);
        form.addView(label, bottom(0, 5));
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, versions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        String savedVersion = prefs.getString("profile_version", versions[0]);
        int chosen = 0;
        for (int i = 0; i < versions.length; i++) if (versions[i].equals(savedVersion)) chosen = i;
        spinner.setSelection(chosen);
        form.addView(spinner);
        new AlertDialog.Builder(this)
                .setTitle("Edit local profile")
                .setView(form)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (dialog, which) -> {
                    String profileName = name.getText().toString().trim();
                    if (profileName.isEmpty()) profileName = "My Profile";
                    String version = spinner.getSelectedItem().toString();
                    prefs.edit().putString("profile_name", profileName)
                            .putString("profile_version", version).apply();
                    selectedProfile.setText("Profile: " + profileName);
                    selectedVersion.setText("Preferred version: " + version);
                    showToast("Profile saved");
                }).show();
    }

    private void launchJava() {
        String[] packages = {"org.angelauramc.amethyst", "org.angelauramc.amethyst.debug", "net.kdt.pojavlaunch", "net.kdt.pojavlauncher", "com.movtery.zalithlauncher"};
        for (String packageName : packages) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch != null) {
                try {
                    startActivity(launch);
                    return;
                } catch (ActivityNotFoundException ignored) { }
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("Java launcher not found")
                .setMessage("Install a compatible Java Edition launcher first. UltraCraft does not include Minecraft or handle account sign-in. The official Amethyst project page has current build information.")
                .setNegativeButton("Not now", null)
                .setPositiveButton("Open project page", (d, w) -> openUrl(AMETHYST_URL))
                .show();
    }

    private void launchBedrock() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
        if (launch != null) {
            try {
                startActivity(launch);
                return;
            } catch (ActivityNotFoundException ignored) { }
        }
        new AlertDialog.Builder(this)
                .setTitle("Bedrock Edition not found")
                .setMessage("Minecraft for Android is not installed. You can open its official Google Play listing; purchase may be required.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open Play Store", (d, w) -> openUrl(BEDROCK_URL))
                .show();
    }

    private void updateInstalledStatuses() {
        if (javaStatus == null) return;
        boolean hasJava = false;
        String[] packages = {"org.angelauramc.amethyst", "org.angelauramc.amethyst.debug", "net.kdt.pojavlaunch", "net.kdt.pojavlauncher", "com.movtery.zalithlauncher"};
        for (String pkg : packages) {
            if (getPackageManager().getLaunchIntentForPackage(pkg) != null) { hasJava = true; break; }
        }
        boolean hasBedrock = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe") != null;
        javaStatus.setText(hasJava ? "INSTALLED" : "NOT FOUND");
        javaStatus.setTextColor(hasJava ? GREEN : MUTED);
        bedrockStatus.setText(hasBedrock ? "INSTALLED" : "NOT FOUND");
        bedrockStatus.setTextColor(hasBedrock ? GREEN : MUTED);
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException ex) {
            showToast("No browser or compatible app found.");
        }
    }

    private LinearLayout panel(int color, int radius) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(round(color, radius));
        return box;
    }

    private TextView sectionTitle(String value) {
        TextView title = text(value, 11, MUTED, true);
        title.setLetterSpacing(0.08f);
        return title;
    }

    private TextView smallIcon(String value, int color) {
        TextView icon = text(value, 18, TEXT, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(round(color, 12));
        return icon;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        t.setIncludeFontPadding(true);
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        b.setTextColor(primary ? Color.rgb(8, 22, 12) : TEXT);
        b.setBackground(round(primary ? GREEN : PANEL_ALT, 13));
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout.LayoutParams bottom(int left, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.leftMargin = dp(left);
        p.bottomMargin = dp(bottom);
        return p;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void showToast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show();
    }
}
