@echo off
setlocal
set "UC_GRADLE_BASE=%USERPROFILE%\.gradle\ultracraft-wrapper"
set "UC_GRADLE_DIST=%UC_GRADLE_BASE%\gradle-8.9"
if not exist "%UC_GRADLE_DIST%\bin\gradle.bat" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$base = Join-Path $env:USERPROFILE '.gradle\ultracraft-wrapper'; New-Item -ItemType Directory -Force -Path $base | Out-Null; $zip = Join-Path $base 'gradle-8.9-bin.zip'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath $base -Force; Remove-Item $zip"
  if errorlevel 1 exit /b 1
)
call "%UC_GRADLE_DIST%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
