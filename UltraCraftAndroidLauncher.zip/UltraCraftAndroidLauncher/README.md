# UltraCraft Android Launcher

A lightweight, native Android companion launcher dashboard for Minecraft Java and Bedrock.

## What works

- Dark, mobile-friendly launcher dashboard.
- Detects compatible Java launcher packages (Amethyst/Pojav-style launchers) and Minecraft Bedrock for Android.
- Quick-launch buttons open an already installed compatible app.
- If a launcher isn't found, provides a route to the relevant official project/store page.
- Saves a local profile name, preferred-version note, and a performance preset using Android SharedPreferences.
- Includes an automated GitHub Actions workflow to build a debug APK.

## Important limitations

This is a **companion launcher**, not a replacement Minecraft game engine. It does not ship Minecraft assets, install game versions/mod loaders, or authenticate Microsoft accounts. The preferred version and performance preset are saved in UltraCraft as notes; choose the actual version and graphics/RAM settings inside your Java launcher. A compatible Java launcher must already be installed to use the Java quick-launch button.

For current Android Java Edition launcher build instructions, see the [Amethyst Android project](https://github.com/AngelAuraMC/Amethyst-Android). The game and a valid license/account may be required.

## Build in Android Studio

1. Open this folder in Android Studio.
2. Use JDK 17 or newer.
3. Install Android SDK Platform 35 when prompted.
4. Run `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`) or use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The included lightweight wrapper downloads the official Gradle 8.9 distribution on first run.
5. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`. If Gradle downloads are blocked on your network, use the GitHub Actions build workflow instead.

## Build with GitHub Actions

Push this folder to a GitHub repository, open **Actions**, and run **Build Android APK** (or push a change under the workflow's watched paths). The workflow uploads `app-debug.apk` as an artifact.

## Package details

- Application ID: `com.ultracraft.launcher`
- Minimum Android version: Android 6.0 (API 23)
- Target SDK: 35
- Version: 1.0.0

UltraCraft is an independent companion app and is not affiliated with Mojang or Microsoft. Minecraft is a trademark of Mojang Studios.
